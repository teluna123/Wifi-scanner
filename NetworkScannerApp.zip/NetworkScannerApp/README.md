# WiFi Network Scanner - Android App

A native Android application that scans your WiFi network and displays all connected devices with their IP addresses, MAC addresses, and device names.

## Features
- ✅ Scan entire WiFi network (all 254 possible hosts)
- ✅ Display device name/hostname
- ✅ Show IP address for each device
- ✅ Show MAC address for each device
- ✅ Modern Material Design UI
- ✅ Real-time scanning progress
- ✅ Works on Android 5.0 (API 21) and above

## How to Build APK

### Method 1: Using Android Studio (Recommended)

1. **Install Android Studio**
   - Download from: https://developer.android.com/studio
   - Install and open Android Studio

2. **Open the Project**
   - Open Android Studio
   - Click "Open an Existing Project"
   - Select the `NetworkScannerApp` folder

3. **Build APK**
   - Go to `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`
   - Wait for build to complete
   - Click "locate" in the notification to find your APK
   - APK will be in: `app/build/outputs/apk/debug/app-debug.apk`

### Method 2: Using Command Line

1. **Install Android SDK and Gradle**
   ```bash
   # On Ubuntu/Debian
   sudo apt-get update
   sudo apt-get install android-sdk gradle
   ```

2. **Build APK**
   ```bash
   cd NetworkScannerApp
   ./gradlew assembleDebug
   ```

3. **Find APK**
   - APK will be in: `app/build/outputs/apk/debug/app-debug.apk`

### Method 3: Online Build (Easiest)

You can use online Android build services:
- **AppGyver** (https://www.appgyver.com/)
- **Kodular** (https://www.kodular.io/)
- Upload the project files and build online

## Installation

1. Transfer the APK to your Android device
2. Enable "Install from Unknown Sources" in Settings
3. Tap the APK file to install
4. Grant WiFi permissions when prompted

## Usage

1. Open the app
2. Make sure you're connected to WiFi
3. Tap "🔍 Start Scan"
4. Wait for scan to complete (1-3 minutes)
5. View all connected devices with their details

## Permissions Required

- **INTERNET**: To communicate with network devices
- **ACCESS_WIFI_STATE**: To get WiFi information
- **ACCESS_NETWORK_STATE**: To check network connectivity

## Technical Details

- **Language**: Java
- **Min SDK**: Android 5.0 (API 21)
- **Target SDK**: Android 13 (API 33)
- **Architecture**: Native Android with Material Design

## Screenshots

The app displays:
- Your device's IP address at the top
- A scan button
- Progress indicator during scanning
- List of found devices showing:
  - Device emoji icon
  - Device name/hostname
  - IP address
  - MAC address

## Limitations

- Some devices may not respond to network pings
- MAC address detection may be limited on newer Android versions due to privacy restrictions
- Scan time depends on network size (typically 1-3 minutes for standard home networks)

## Troubleshooting

**No devices found?**
- Make sure you're connected to WiFi (not mobile data)
- Grant all requested permissions
- Some networks may block scanning (corporate/hotel WiFi)

**Can't install APK?**
- Enable "Install from Unknown Sources" in Settings → Security
- Make sure you're installing the debug version for testing

## Building for Release

For a production-ready app:

1. Generate a signing key
2. Update `build.gradle` with signing config
3. Build with: `./gradlew assembleRelease`

## Support

For issues or questions about building, refer to:
- Android Developer Guide: https://developer.android.com/guide
- Gradle Documentation: https://docs.gradle.org/

---

**Note**: This is a network scanning tool. Use responsibly and only on networks you own or have permission to scan.
