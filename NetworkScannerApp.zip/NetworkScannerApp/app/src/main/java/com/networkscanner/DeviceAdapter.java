package com.networkscanner;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.List;

public class DeviceAdapter extends ArrayAdapter<Device> {
    
    public DeviceAdapter(Context context, List<Device> devices) {
        super(context, 0, devices);
    }
    
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Device device = getItem(position);
        
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(
                R.layout.device_item, parent, false);
        }
        
        TextView deviceName = convertView.findViewById(R.id.deviceName);
        TextView deviceIp = convertView.findViewById(R.id.deviceIp);
        TextView deviceMac = convertView.findViewById(R.id.deviceMac);
        
        deviceName.setText("📱 " + device.getName());
        deviceIp.setText("IP: " + device.getIpAddress());
        deviceMac.setText("MAC: " + device.getMacAddress());
        
        return convertView;
    }
}
