package com.networkscanner;

import android.Manifest;
import android.content.pm.PackageManager;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.format.Formatter;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    
    private static final int PERMISSION_REQUEST_CODE = 1;
    private ListView deviceListView;
    private Button scanButton;
    private ProgressBar progressBar;
    private TextView statusText;
    private TextView myIpText;
    private DeviceAdapter deviceAdapter;
    private List<Device> deviceList;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        // Initialize views
        deviceListView = findViewById(R.id.deviceListView);
        scanButton = findViewById(R.id.scanButton);
        progressBar = findViewById(R.id.progressBar);
        statusText = findViewById(R.id.statusText);
        myIpText = findViewById(R.id.myIpText);
        
        // Initialize device list
        deviceList = new ArrayList<>();
        deviceAdapter = new DeviceAdapter(this, deviceList);
        deviceListView.setAdapter(deviceAdapter);
        
        // Display local IP
        displayLocalIP();
        
        // Check permissions
        if (!checkPermissions()) {
            requestPermissions();
        }
        
        // Scan button click listener
        scanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkPermissions()) {
                    startNetworkScan();
                } else {
                    requestPermissions();
                }
            }
        });
    }
    
    private boolean checkPermissions() {
        int accessWifiState = ContextCompat.checkSelfPermission(this, 
            Manifest.permission.ACCESS_WIFI_STATE);
        int internet = ContextCompat.checkSelfPermission(this, 
            Manifest.permission.INTERNET);
        int accessNetworkState = ContextCompat.checkSelfPermission(this, 
            Manifest.permission.ACCESS_NETWORK_STATE);
        
        return accessWifiState == PackageManager.PERMISSION_GRANTED &&
               internet == PackageManager.PERMISSION_GRANTED &&
               accessNetworkState == PackageManager.PERMISSION_GRANTED;
    }
    
    private void requestPermissions() {
        ActivityCompat.requestPermissions(this, new String[]{
            Manifest.permission.ACCESS_WIFI_STATE,
            Manifest.permission.INTERNET,
            Manifest.permission.ACCESS_NETWORK_STATE
        }, PERMISSION_REQUEST_CODE);
    }
    
    private void displayLocalIP() {
        String ip = getLocalIPAddress();
        myIpText.setText("Your IP: " + ip);
    }
    
    private String getLocalIPAddress() {
        try {
            WifiManager wifiManager = (WifiManager) getApplicationContext()
                .getSystemService(WIFI_SERVICE);
            WifiInfo wifiInfo = wifiManager.getConnectionInfo();
            int ipAddress = wifiInfo.getIpAddress();
            return Formatter.formatIpAddress(ipAddress);
        } catch (Exception e) {
            return "Unable to get IP";
        }
    }
    
    private void startNetworkScan() {
        deviceList.clear();
        deviceAdapter.notifyDataSetChanged();
        
        scanButton.setEnabled(false);
        progressBar.setVisibility(View.VISIBLE);
        statusText.setText("Scanning network...");
        
        new NetworkScanTask().execute();
    }
    
    private class NetworkScanTask extends AsyncTask<Void, Device, Integer> {
        
        @Override
        protected Integer doInBackground(Void... voids) {
            try {
                String localIP = getLocalIPAddress();
                String subnet = localIP.substring(0, localIP.lastIndexOf("."));
                
                int devicesFound = 0;
                
                // Scan all IPs in subnet
                for (int i = 1; i <= 254; i++) {
                    if (isCancelled()) break;
                    
                    String host = subnet + "." + i;
                    
                    try {
                        InetAddress address = InetAddress.getByName(host);
                        
                        // Try to reach with 1 second timeout
                        if (address.isReachable(1000)) {
                            String hostname = address.getHostName();
                            String mac = getMacAddress(host);
                            
                            Device device = new Device(
                                hostname.equals(host) ? "Unknown Device" : hostname,
                                host,
                                mac
                            );
                            
                            publishProgress(device);
                            devicesFound++;
                        }
                    } catch (IOException e) {
                        // Host not reachable
                    }
                }
                
                return devicesFound;
                
            } catch (Exception e) {
                e.printStackTrace();
                return 0;
            }
        }
        
        @Override
        protected void onProgressUpdate(Device... devices) {
            deviceList.add(devices[0]);
            deviceAdapter.notifyDataSetChanged();
            statusText.setText("Found " + deviceList.size() + " device(s)");
        }
        
        @Override
        protected void onPostExecute(Integer devicesFound) {
            scanButton.setEnabled(true);
            progressBar.setVisibility(View.GONE);
            
            if (devicesFound == 0) {
                statusText.setText("No devices found");
                Toast.makeText(MainActivity.this, 
                    "No devices found. Make sure you're connected to WiFi.", 
                    Toast.LENGTH_LONG).show();
            } else {
                statusText.setText("Scan complete! Found " + devicesFound + " device(s)");
            }
        }
    }
    
    private String getMacAddress(String ipAddress) {
        try {
            InetAddress address = InetAddress.getByName(ipAddress);
            NetworkInterface network = NetworkInterface.getByInetAddress(address);
            
            if (network != null) {
                byte[] mac = network.getHardwareAddress();
                
                if (mac != null) {
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < mac.length; i++) {
                        sb.append(String.format("%02X%s", mac[i], 
                            (i < mac.length - 1) ? ":" : ""));
                    }
                    return sb.toString();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "N/A";
    }
}
