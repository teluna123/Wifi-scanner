package com.networkscanner;

public class Device {
    private String name;
    private String ipAddress;
    private String macAddress;
    
    public Device(String name, String ipAddress, String macAddress) {
        this.name = name;
        this.ipAddress = ipAddress;
        this.macAddress = macAddress;
    }
    
    public String getName() {
        return name;
    }
    
    public String getIpAddress() {
        return ipAddress;
    }
    
    public String getMacAddress() {
        return macAddress;
    }
}
